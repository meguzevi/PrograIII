﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Capaproceso;
namespace Capausuario
{
    public partial class edades : Form
    {
        public edades()
        {
            InitializeComponent();
        }
        Boolean Respuesta = false;
        public void calcular()
        {
            calculos calculaedades = new calculos();

            Respuesta = calculaedades.Edades(int.Parse(edad1.Text), int.Parse(edad2.Text));


        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            calcular();
            ResultadoC.Text = Convert.ToString(Respuesta);
        }
    }
}
