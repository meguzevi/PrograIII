﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Capaproceso;

namespace Capausuario
{
    public partial class luz : Form
    {
        public luz()
        {
            InitializeComponent();
        }


        double resultado1,conversion1;
        double segundos=60;
        public void calcularluz()
        {
            calculos calcula = new calculos();
            
            resultado1 = calcula.Multiplicar(double.Parse(minutos.Text), segundos);
            conversion1 = calcula.Multiplicar(resultado1, double.Parse(km.Text));


        }



        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            calcularluz();
            total.Text = Convert.ToString(conversion1);
        }
    }
}
