﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Capaproceso;

namespace Capausuario
{
    public partial class promedio : Form
    {
        public promedio()
        {
            InitializeComponent();
        }


        double resultado1, sumar;
     
        public void materias()
        {
            calculos calcula = new calculos();
           // for (int i = 0; i < int.Parse(Nmaterias.Text); i++)
            sumar =(double.Parse(nota1.Text)+double.Parse(nota2.Text)+double.Parse(nota3.Text)+ double.Parse(nota4.Text)+double.Parse(nota5.Text));
            resultado1 = calcula.divide(sumar, double.Parse(Nmaterias.Text));
     


        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            materias();
            prom.Text = Convert.ToString(resultado1);
        }
    }
}
