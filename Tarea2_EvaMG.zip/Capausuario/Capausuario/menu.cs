﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Capaproceso;
namespace Capausuario
{
    public partial class menu : Form
    {


        public menu()
        {
            InitializeComponent();

        }
       //var  numerosPares = new List<int>();

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }
        public void seleccionar()
        {
            AreaTriangulo Area1 = new AreaTriangulo();
            convertir Conver= new convertir();
            edades edad = new edades();
            grados gra1 = new grados();
            lustro lustro1 = new lustro();
            luz luz = new luz();
            llanta vuelta = new llanta();
            sombra som = new sombra();
            meses mes = new meses();
            promedio prom = new promedio();
            /*
            if (opciones.SelectedItem != null)
            {
                MessageBox.Show(opciones.SelectedItem.ToString()); Devuelve el valor del elemento
            }
            */
                            
            if (opciones.SelectedIndex != -1)
            {
               
                //  for (var c = 0; c < 10; c++)
                if (opciones.SelectedIndex == 0) // Area
                    Area1.Show();
                //MessageBox.Show(opciones.SelectedIndex.ToString());
               
                else
                if (opciones.SelectedIndex == 1) // Conversion de moneda
                Conver.Show();
                //MessageBox.Show(opciones.SelectedIndex.ToString());
                else
                if (opciones.SelectedIndex == 2) //compara edades
                    edad.Show();
                else
                if (opciones.SelectedIndex == 3) // grados centigrados a fahren
                    gra1.Show();
                else
                if (opciones.SelectedIndex == 4) // convertir de lutro a segundo
                    lustro1.Show();
                else
                if (opciones.SelectedIndex == 5) // convertir luz del sol a marte en segundos
                    luz.Show();
                else
                if (opciones.SelectedIndex == 6) // vueltas de la llanta
                    vuelta.Show();
                else
                if (opciones.SelectedIndex == 7) // Sombra edificio
                    som.Show();
                 else
                if (opciones.SelectedIndex == 8) // meses
                mes.Show();
                else
                if (opciones.SelectedIndex == 9) // promedio
                    prom.Show();
            }
    }
        private void button1_Click(object sender, EventArgs e)
        {
            seleccionar();
        }

        private void opciones_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void menu_Load(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
