﻿namespace Capausuario
{
    partial class convertir
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Gropu = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.Calcular = new System.Windows.Forms.Button();
            this.TipoC = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.resultadCon = new System.Windows.Forms.Label();
            this.montoD = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Gropu.SuspendLayout();
            this.SuspendLayout();
            // 
            // Gropu
            // 
            this.Gropu.Controls.Add(this.button2);
            this.Gropu.Controls.Add(this.Calcular);
            this.Gropu.Controls.Add(this.TipoC);
            this.Gropu.Controls.Add(this.label3);
            this.Gropu.Controls.Add(this.resultadCon);
            this.Gropu.Controls.Add(this.montoD);
            this.Gropu.Controls.Add(this.label2);
            this.Gropu.Controls.Add(this.label1);
            this.Gropu.Location = new System.Drawing.Point(24, 22);
            this.Gropu.Name = "Gropu";
            this.Gropu.Size = new System.Drawing.Size(391, 195);
            this.Gropu.TabIndex = 0;
            this.Gropu.TabStop = false;
            this.Gropu.Text = "Convertir de dolar a colon";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(310, 166);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 7;
            this.button2.Text = "Salir";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Calcular
            // 
            this.Calcular.Location = new System.Drawing.Point(56, 140);
            this.Calcular.Name = "Calcular";
            this.Calcular.Size = new System.Drawing.Size(75, 23);
            this.Calcular.TabIndex = 6;
            this.Calcular.Text = "Calcular";
            this.Calcular.UseVisualStyleBackColor = true;
            this.Calcular.Click += new System.EventHandler(this.Calcular_Click);
            // 
            // TipoC
            // 
            this.TipoC.AutoSize = true;
            this.TipoC.Location = new System.Drawing.Point(258, 16);
            this.TipoC.Name = "TipoC";
            this.TipoC.Size = new System.Drawing.Size(0, 13);
            this.TipoC.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(109, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(114, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Tipo de cambio del dìa";
            // 
            // resultadCon
            // 
            this.resultadCon.AutoSize = true;
            this.resultadCon.Location = new System.Drawing.Point(178, 109);
            this.resultadCon.Name = "resultadCon";
            this.resultadCon.Size = new System.Drawing.Size(0, 13);
            this.resultadCon.TabIndex = 3;
            // 
            // montoD
            // 
            this.montoD.Location = new System.Drawing.Point(122, 59);
            this.montoD.Name = "montoD";
            this.montoD.Size = new System.Drawing.Size(82, 20);
            this.montoD.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 109);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(136, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Resultado de la conversion";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Monto en Dolar";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // convertir
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(443, 240);
            this.Controls.Add(this.Gropu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "convertir";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "convertir";
            this.Gropu.ResumeLayout(false);
            this.Gropu.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox Gropu;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label TipoC;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label resultadCon;
        private System.Windows.Forms.TextBox montoD;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button Calcular;
    }
}