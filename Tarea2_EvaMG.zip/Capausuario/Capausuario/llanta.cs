﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Capaproceso;
namespace Capausuario
{
    public partial class llanta : Form
    {
        public llanta()
        {
            InitializeComponent();
        }


        double resultado1, radio,conversion1,metros,final ;

        public void diametro()
        {
            calculos calcula = new calculos();
            radio=Convert.ToDouble(diam.Text)/2; // sacar diametro
            resultado1 = calcula.Multiplicar(2, Math.PI); // multiplicar 2 por P ** PI es una funcion matematica como tal en C#
            conversion1 = calcula.Multiplicar(resultado1, radio);// Radio por la multiplicacion anterior
            metros = calcula.Multiplicar(conversion1, 0.01);///pasar de centimetros a metros
            final = calcula.Vueltastotales(metros); 
        }
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Salir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Calcular_Click(object sender, EventArgs e)
        {
            diametro();
            vueltas1.Text = Convert.ToString(final);
        }
    }
}
