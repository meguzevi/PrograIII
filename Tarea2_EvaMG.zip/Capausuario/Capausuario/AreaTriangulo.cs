﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Capaproceso;
namespace Capausuario
{
    public partial class AreaTriangulo : Form
    {
        public AreaTriangulo()
        {
            InitializeComponent();
        }
        double resultado1;
        public void calcular()
        {
            calculos CalculodeArea = new calculos();

            resultado1 = CalculodeArea.Multiplicar(double.Parse(ancho.Text), double.Parse(Alto.Text));

            
        }

    private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void AreaTriangulo_Load(object sender, EventArgs e)
        {

        }

        private void Salir_Click(object sender, EventArgs e)
        {
           // AreaTriangulo = cq.labelinfo();
         //   AreaTriangulo mv = new AreaTriangulo();
         //  mv.Show();
          this.Close();
        }

        private void Calcular_Click(object sender, EventArgs e)
        {

         
                calcular();
                calculado.Text = Convert.ToString(resultado1);
        }
    }
}
