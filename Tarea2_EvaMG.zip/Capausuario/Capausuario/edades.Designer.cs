﻿namespace Capausuario
{
    partial class edades
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Comparar = new System.Windows.Forms.GroupBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.edad1 = new System.Windows.Forms.TextBox();
            this.edad2 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.ResultadoC = new System.Windows.Forms.Label();
            this.Comparar.SuspendLayout();
            this.SuspendLayout();
            // 
            // Comparar
            // 
            this.Comparar.Controls.Add(this.ResultadoC);
            this.Comparar.Controls.Add(this.label3);
            this.Comparar.Controls.Add(this.button2);
            this.Comparar.Controls.Add(this.button1);
            this.Comparar.Controls.Add(this.edad2);
            this.Comparar.Controls.Add(this.edad1);
            this.Comparar.Controls.Add(this.label2);
            this.Comparar.Controls.Add(this.label1);
            this.Comparar.Location = new System.Drawing.Point(23, 27);
            this.Comparar.Name = "Comparar";
            this.Comparar.Size = new System.Drawing.Size(428, 260);
            this.Comparar.TabIndex = 0;
            this.Comparar.TabStop = false;
            this.Comparar.Text = "Comparar Edades";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(54, 74);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Edad 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(54, 111);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Edad 2";
            // 
            // edad1
            // 
            this.edad1.Location = new System.Drawing.Point(131, 71);
            this.edad1.Name = "edad1";
            this.edad1.Size = new System.Drawing.Size(141, 20);
            this.edad1.TabIndex = 2;
            // 
            // edad2
            // 
            this.edad2.Location = new System.Drawing.Point(131, 111);
            this.edad2.Name = "edad2";
            this.edad2.Size = new System.Drawing.Size(141, 20);
            this.edad2.TabIndex = 3;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(303, 101);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "Calcular";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(347, 231);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 5;
            this.button2.Text = "Salir";
            this.button2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(54, 176);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(125, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Las edades son Iguales?";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // ResultadoC
            // 
            this.ResultadoC.AutoSize = true;
            this.ResultadoC.Location = new System.Drawing.Point(185, 176);
            this.ResultadoC.Name = "ResultadoC";
            this.ResultadoC.Size = new System.Drawing.Size(0, 13);
            this.ResultadoC.TabIndex = 7;
            // 
            // edades
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(489, 316);
            this.Controls.Add(this.Comparar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "edades";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Comparar.ResumeLayout(false);
            this.Comparar.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox Comparar;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox edad2;
        private System.Windows.Forms.TextBox edad1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Label ResultadoC;
    }
}