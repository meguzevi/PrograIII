﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Capaproceso;
namespace Capausuario
{
    public partial class grados : Form
    {
        public grados()
        {
            InitializeComponent();
        }
        double convertido;
       // double tipo = 638;



        public void convertirgrados()
        {
            calculos gradosC_F = new calculos();
            convertido = gradosC_F.gradosC(double.Parse(centigrado.Text));


        }


        private void Calcular_Click(object sender, EventArgs e)
        {
            convertirgrados();
            Fahren.Text = Convert.ToString(convertido);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();

        }
    }
}
