﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Capaproceso;
namespace Capausuario
{
    public partial class sombra : Form
    {
        public sombra()
        {
            InitializeComponent();
        }
        double resultado1,convertir;
        double tangent;
        public void sombra2()
        {
            calculos calcula = new calculos();
            
            tangent = Math.Tan(Convert.ToDouble(angulo.Text)); // tangente en radianes https://www.calculadoras.uno/tangente/grados/22

//            convertir = calcula.Multiplicar(tangent, calcula.divide(180, Math.PI));
            resultado1 = calcula.divide(double.Parse(metrosE.Text), tangent);
          


        }




        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Calcular_Click(object sender, EventArgs e)
        {
            sombra2();
            total.Text = Convert.ToString(resultado1);
        }
    }
}
