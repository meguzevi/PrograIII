﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capaproceso
{
    public class calculos
    {
        double AreaResul =0;
        Boolean compara = false;
        public double Multiplicar(double campo1, double campo2) // Calcula Area del triangulo y conversion de dolar a colon
            {
            AreaResul = campo1 * campo2; 
             return AreaResul; 
        
            }
        
        public Boolean Edades(int edad1, int edad2) // Compara edades
        {
            if (edad1 == edad2)
                compara = true;
           return compara;

        }


        public double gradosC(double campo1) // Calcula formula de grados centigrados a fahrenheit
        {
            AreaResul = (campo1*9/5) +32;
            return AreaResul;

        }
        public double Vueltastotales(double campo1) // Calcula formula de grados centigrados a fahrenheit
        {
            AreaResul = (1000 - 1) / campo1;
            return AreaResul;

        }

        public double divide(double campo1,double campo2) // Calculo de sombra
        {
            AreaResul = campo1 / campo2;
            return AreaResul;

        }

        public  decimal mesesdiferencia(DateTime FechaFin, DateTime FechaInicio) // Fecha diferencia
        {
            return Math.Abs((FechaFin.Month - FechaInicio.Month) + 12 * (FechaFin.Year - FechaInicio.Year));

        }

    }
}
